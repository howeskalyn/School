#include "Lab6.cpp"
