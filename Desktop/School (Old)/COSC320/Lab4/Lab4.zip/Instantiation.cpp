#include "Lab4.cpp"
#include "HeapQ.cpp"

template class HeapQ<int>; // instatiates a HeapQ of ints
template class HeapQ<string>; // instatiates a HeapQ of strings
