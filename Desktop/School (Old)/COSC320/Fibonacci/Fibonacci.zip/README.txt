Kalyn Howes
3.4.21
Lab 5 - Bonus

I completed the Fibonacci bonus question. In order to make changes and re-run this program, a make clean command is required. Here is some output:

----------------------------------------

Time starts now: 

The 9th Fibonacci number is 34.
2925 arithmetic operations were needed.

finished at Wed Mar  3 12:21:44 2021
elapsed time: 0.000117s

----------------------------------------

Time starts now: 

The 3th Fibonacci number is 2.
113 arithmetic operations were needed.

finished at Wed Mar  3 12:25:22 2021
elapsed time: 3.4e-05s

----------------------------------------

Time starts now: 

The 0th Fibonacci number is 0.
0 arithmetic operations were needed.

finished at Wed Mar  3 12:27:23 2021
elapsed time: 1.7e-05s

----------------------------------------

Time starts now: 

The 1th Fibonacci number is 1.
0 arithmetic operations were needed.

finished at Wed Mar  3 12:27:49 2021
elapsed time: 1.8e-05s

