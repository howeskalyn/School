Kalyn Howes
10.10.21
Lab2
README.txt


Practice efficiently manipulating data with Python, using the matplotlib & pandas libraries, and gain familiarity with data import and plotting. 

All questions are answered in the notebook under their charts/plots.

Some cells need to be run prior to ones after them or errors may occur.