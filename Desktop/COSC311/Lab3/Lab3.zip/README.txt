README
Lab 3
Kalyn Howes & Chloe VanCory
10.26.21
______________________________________________________________


Notes for Running:

-Ensure cells 1, 2, and 5 are run prior to cells 6 and on. These cells bring in imports, the data itself and set up the differing classes.

-Along with python libraries, a stats.py and probability.py are imported. These include "hand-made" functions that are used in the notebook.

-All questions have been answered in the Jupyter notebook itself with either markdown text or print statements and graphs.