Lab 4
COSC 311
Kalyn Howes & Chloe VanCory
11.5.21
__________________________________________________________________________________

As always, some cells may not run if ones prior are not run first. The easiest way to ensure the notebook works correctly is to run each cell sequentially from the top down. 

The cell for question vi may take a little longer to run since it is plotting about 40 graphs. This will also show the following warning: 

"/Applications/JupyterLab.app/Contents/Resources/jlab_server/lib/python3.8/site-packages/pandas/plotting/_matplotlib/tools.py:218: RuntimeWarning: More than 20 figures have been opened. Figures created through the pyplot interface (`matplotlib.pyplot.figure`) are retained until explicitly closed and may consume too much memory. (To control this warning, see the rcParam `figure.max_open_warning`).
  fig = plt.figure(**fig_kw)"

This warning is not an issue and the program should continue normally.

All questions have been answered in the notebook itself, except the hand-written work for #3 which has been turned in separately.